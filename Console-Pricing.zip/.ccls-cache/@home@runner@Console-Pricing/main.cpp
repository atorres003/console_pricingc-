#include <iostream>
#include <string>
#include <vector>
#include <fstream>
using namespace std;

void show_consoles(vector<string> console1, vector<string> console2){
     cout << "Below are the available consoles for sale:" << endl;
     for(int i = 0; i < console1.size(); i++ ) {
       cout << "\t" << console1.at(i) << " - " << console2.at(i) << endl;
     }
}

void show_prices(vector<string> console1, vector<string> console2, vector<int> console1prices, vector<int> console2prices){
     cout << "Below are the prices for each console below:" << endl;
  for(int i = 0; i < console1.size(); i++) {
  cout << "\t" << console1.at(i) << " - " << console2.at(i) << endl;
  cout << "\t" << console1prices.at(i) << " - " << console2prices.at(i) << endl;
    }
}

void print_menu() {
    cout << "***********************************************" << endl;
    cout << endl;
    cout << "Welcome to the virtual gamer shop!" << endl;
    cout << endl;
    cout << "There are 3 video game consoles available this Holiday Season! Each console has two sub-options to choose from!" << endl;
    cout << endl;
    cout << "c - show consoles" << endl;
    cout << "p - show pricing" << endl;
    cout << "q - quit" << endl;
    cout << endl;
    cout << "***********************************************" << endl;
    cout << "Please enter your choice:" << endl;
}

void initialize_data(vector<string>& console1, vector<string>& console2, vector<int>& console1prices, vector<int>& console2prices) {
  
  ifstream fin;
  string temp_s;
  int temp_i;
  
  fin.open("data.txt");
  if(fin.is_open() ){
     while(!fin.eof() ){
       fin >> temp_s;
       console1.push_back(temp_s);
       fin >> temp_s;
       console2.push_back(temp_s);
       fin >> temp_i;
       console1prices.push_back(temp_i);
       fin >> temp_i;
       console2prices.push_back(temp_i);
     }
    fin.close();
    cout << "Initialized " << console1.size() << " available consoles..." << endl;
    
    
  } else {
    cout << "Error while reading file" << endl;
  }
}

void save_data(vector<string> console1, vector<string> console2, vector<int> console1prices, vector<int> console2prices){
ofstream fout;
  fout.open("saved_data.txt");
  if(fout.is_open() ) {
    for(int i = 0; i < console1.size(); i++ ) {
      fout << console1.at(i) << "," << console1prices.at(i) << "," << console2.at(i) << "," << console2prices.at(i) << endl;
    }
    fout.close();
  } else {
     cout << "Error while saving..." << endl;
  }
}

int main() {
char user_input;

vector<string> console1;
vector<string> console2;
vector<int> console1prices;
vector<int> console2prices;

initialize_data(console1, console2, console1prices, console2prices);

  
do {
    print_menu();
    cin >> user_input;

    switch(user_input){

      case 'c':
      show_consoles(console1, console2);
      break;
      case 'p':
      show_prices(console1, console2, console1prices, console2prices);
      break;
      case 'q':
      cout << "Thank you for stopping by the virtual gamer shop! Happy Holidays! " << endl;
      save_data(console1, console2, console1prices, console2prices);
      break;
      
      default: 
      cout << "Ouch! Looks like you entered an invalid option. Please try again!" << endl;
    }
  
}   while(user_input != 'q'); 
  
return 0;
}